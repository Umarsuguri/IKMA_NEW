#include "stm32f4xx_hal.h"
void read_sensor_data(uint8_t sens[16]);
